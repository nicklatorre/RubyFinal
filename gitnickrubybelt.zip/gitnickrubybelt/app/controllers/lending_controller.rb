class LendingController < ApplicationController
  
end
